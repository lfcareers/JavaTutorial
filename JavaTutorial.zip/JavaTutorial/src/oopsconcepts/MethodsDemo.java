package oopsconcepts;

public class MethodsDemo {
	
	String a = "Hey, there !!!";

	public static void main(String[] args) {
		String a = "Hey, there !!!";
		System.out.println(a);

	}
	
	public static void methodNum() {
		String a = "Hey, there !!!";
		System.out.println(a);
	}

}
