package introduction;

public class HelloWorld {

	public static void main(String[] args) {
		// This is my 1st java program
		/*
		 * This
		 * is
		 * my
		 * 1st java program
		 */
		
		System.out.println("Hello World!");
	}

}
